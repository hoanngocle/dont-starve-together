return {
  ["workshop-1207269058"]={ configuration_options={  }, enabled=true },
  ["workshop-1462979419"]={
    configuration_options={ backpackCategory="resources", funMode="yes", keybind=103, maxLights=2 },
    enabled=true 
  },
  ["workshop-1530801499"]={
    configuration_options={
      ArrowsignEnable=false,
      CountdownEnable=false,
      HungerCost=1,
      Ownership=false,
      SanityCost=1 
    },
    enabled=true 
  },
  ["workshop-1535658505"]={ configuration_options={ RECIPE=1 }, enabled=true },
  ["workshop-1595631294"]={
    configuration_options={
      BundleItems=false,
      ChangeSkin=true,
      Digornot=false,
      DragonflyChest=false,
      Icebox=true,
      SaltBox=false 
    },
    enabled=true 
  },
  ["workshop-1686705509"]={ configuration_options={  }, enabled=true },
  ["workshop-1845106626"]={ configuration_options={ more_fuel=1 }, enabled=true },
  ["workshop-2336991112"]={
    configuration_options={
      [""]=0,
      ["Basic Stats"]=0,
      ["Guzzler Hat"]=0,
      Kazoo=0,
      ["Other Perks"]=0,
      Scythe=0,
      ["Sleeping (Death)"]=0,
      Souls=0,
      ["Visual Config"]=0,
      calliope_clothes=false,
      calliope_cursed=true,
      calliope_dmg=1,
      calliope_hat_conversion=2,
      calliope_hat_durability=9,
      calliope_hat_interval=6,
      calliope_hat_recipe=1,
      calliope_health=125,
      calliope_hud=true,
      calliope_hunger=125,
      calliope_hunger_rate=1,
      calliope_immortal=true,
      calliope_kazoo_durability=4,
      calliope_mori_grave=0.05,
      calliope_reap_counter=100,
      calliope_reap_heal=5,
      calliope_reap_onhurt=1,
      calliope_sanity=200,
      calliope_scythe_crit_dmg=3,
      calliope_scythe_dmg=68,
      calliope_scythe_durability=9999,
      calliope_scythe_maxrate=100,
      calliope_scythe_recipe=0,
      calliope_sleep_duration=10,
      calliope_sleep_penalty=true,
      calliope_sleep_recovery=5,
      calliope_sleep_soulrate=1,
      calliope_soul_strike=5,
      calliope_speed=1,
      calliope_starters=true,
      calliope_tsun=true 
    },
    enabled=true 
  },
  ["workshop-2675609101"]={
    configuration_options={
      circle=true,
      damage=10,
      display=1,
      durability=-1,
      fix=1,
      language=false,
      light=true,
      make=true,
      null=0,
      number=6,
      planardamage=20,
      radius=3.75,
      recipe=0,
      repairable=true,
      shining=false,
      slot=2,
      speed=1 
    },
    enabled=true 
  },
  ["workshop-2898491859"]={ configuration_options={ language="en" }, enabled=true },
  ["workshop-2937640068"]={
    configuration_options={
      [""]=0,
      ABSORBGAIN=0.005,
      ASSISTRANGE=30,
      BUILDXP=true,
      COOKXP=true,
      DAMAGEGAIN=0.005,
      EXP_MULT=1,
      FISHXP=true,
      FOODXP=true,
      HEALTHGAIN=5,
      HPPENALTY=false,
      HUNGERGAIN=5,
      INITALSTARS=50,
      KILLXP=true,
      LANGUAGE="vi",
      LEVELPOINTS=5,
      LEVEL_LIMIT=0,
      LOGING=true,
      MAX_ABSORBGAIN=0.9,
      NOAWARDS=false,
      NOTIFICATION=true,
      PLANTXP=true,
      PLAYS=3,
      REFUND=1,
      SANITYGAIN=5,
      SHORTCUT=true,
      SPEEDGAIN=0.005,
      TESTING=false,
      WORKXP=true 
    },
    enabled=true 
  },
  ["workshop-3383078008"]={ configuration_options={ linkradius=30, wirelessterminal=true }, enabled=true },
  ["workshop-362175979"]={ configuration_options={ ["Draw over FoW"]="disabled" }, enabled=true },
  ["workshop-374550642"]={
    configuration_options={
      STACK_SIZE_LARGEITEM=500,
      STACK_SIZE_MEDITEM=500,
      STACK_SIZE_SMALLITEM=500,
      STACK_SIZE_TINYITEM=500 
    },
    enabled=true 
  },
  ["workshop-375850593"]={ configuration_options={  }, enabled=true },
  ["workshop-466732225"]={ configuration_options={  }, enabled=true },
  ["workshop-488018406"]={ configuration_options={  }, enabled=true },
  ["workshop-587832350"]={ configuration_options={ craft="easy" }, enabled=true },
  ["workshop-625415718"]={ configuration_options={  }, enabled=true },
  ["workshop-785295023"]={
    configuration_options={
      bossres=true,
      companion=true,
      dist=2.5,
      healthmul=-1,
      language="AUTO",
      minimapicon=false,
      ownership=0,
      rebounddmg=20,
      recipe="normal",
      recipe_door=true,
      recipe_fence=true,
      recipe_tool=true,
      recipe_vanilla=false,
      recipe_wall=true 
    },
    enabled=true 
  },
  ["workshop-786556008"]={
    configuration_options={ ENABLEBACKPACK=false, EXTRASLOT=3, INVENTORYSIZE=45 },
    enabled=true 
  } 
}